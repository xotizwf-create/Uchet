from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import Boolean, Column, Date, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from backend.db import Base


def generate_uuid() -> str:
    return str(uuid.uuid4())


class Contract(Base):
    __tablename__ = "contracts"

    id = Column(String, primary_key=True, default=generate_uuid)
    order_index = Column(Integer, nullable=False, default=0)
    force_done = Column(Boolean, default=False)
    date = Column(Date, nullable=True)
    deadline = Column(Date, nullable=True)
    supplier = Column(String, default="")
    org = Column(String, default="")
    date_fact = Column(Date, nullable=True)
    docs_sent = Column(Boolean, default=False)
    number = Column(String, default="")
    link_url = Column(String, default="")
    item = Column(String, default="")
    qty = Column(Float, default=0)
    plan_qty = Column(Float, default=0)
    plan_date = Column(Date, nullable=True)
    delivered = Column(Float, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)

    items = relationship(
        "ContractItem",
        back_populates="contract",
        cascade="all, delete-orphan",
        passive_deletes=True,
        order_by="ContractItem.position",
    )


class ContractItem(Base):
    __tablename__ = "contract_items"

    id = Column(Integer, primary_key=True)
    contract_id = Column(String, ForeignKey("contracts.id", ondelete="CASCADE"), nullable=False)
    position = Column(Integer, default=0)
    item = Column(String, default="")
    qty = Column(Float, default=0)
    plan_qty = Column(Float, default=0)
    plan_date = Column(Date, nullable=True)
    date_fact = Column(Date, nullable=True)
    delivered = Column(Float, default=0)

    contract = relationship("Contract", back_populates="items")


class WarehouseItem(Base):
    __tablename__ = "warehouse_items"

    id = Column(String, primary_key=True, default=generate_uuid)
    name = Column(String, nullable=False)
    unit = Column(String, default="")
    active = Column(Boolean, default=True)


class WarehouseIncome(Base):
    __tablename__ = "warehouse_incomes"

    id = Column(String, primary_key=True, default=generate_uuid)
    item = Column(String, nullable=False)
    invoice_number = Column(String, default="")
    date = Column(Date, nullable=True)
    qty = Column(Float, default=0)
    unit = Column(String, default="")
    in_stock = Column(Boolean, default=True)


class WarehouseExpense(Base):
    __tablename__ = "warehouse_expenses"

    id = Column(String, primary_key=True, default=generate_uuid)
    org = Column(String, default="")
    date = Column(Date, nullable=True)
    item = Column(String, default="")
    qty = Column(Float, default=0)
    contract_number = Column(String, default="")


class PriceItem(Base):
    __tablename__ = "price_items"

    id = Column(Integer, primary_key=True)
    code = Column(String, default="")
    name = Column(String, default="")
    price_no_vat = Column(Float, default=0)
    price_with_vat = Column(Float, default=0)
    note = Column(String, default="")


class DriveFile(Base):
    __tablename__ = "drive_files"

    id = Column(String, primary_key=True, default=generate_uuid)
    user_id = Column(String, nullable=False, default="default")
    name = Column(String, nullable=False)
    storage_name = Column(String, nullable=False)
    mime_type = Column(String, default="application/octet-stream")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)


class CommercialsState(Base):
    __tablename__ = "commercials_state"

    id = Column(Integer, primary_key=True, default=1)
    headers = Column(Text, default="")
    main_rows = Column(Text, default="")
    params = Column(Text, default="")
    templates = Column(Text, default="")
    kp_tables = Column(Text, default="")
    organization = Column(String, default="")
    organization_options = Column(Text, default="")


class ArchiveEntry(Base):
    __tablename__ = "archive_entries"

    id = Column(String, primary_key=True, default=generate_uuid)
    filename = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
