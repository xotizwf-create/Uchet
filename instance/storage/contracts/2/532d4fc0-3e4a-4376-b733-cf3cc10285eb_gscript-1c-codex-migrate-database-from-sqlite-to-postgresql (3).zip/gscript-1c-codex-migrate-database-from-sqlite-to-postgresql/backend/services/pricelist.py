from __future__ import annotations

from typing import Any, Dict, List

from sqlalchemy import select

from backend.db import SessionLocal
from backend.models import PriceItem


def list_prices() -> List[Dict[str, Any]]:
    session = SessionLocal()
    try:
        items = session.execute(select(PriceItem)).scalars().all()
        return [
            {
                "code": item.code,
                "name": item.name,
                "priceNoVat": item.price_no_vat,
                "priceWithVat": item.price_with_vat,
                "note": item.note,
            }
            for item in items
        ]
    finally:
        session.close()


def handle(action: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    if action == "list":
        return {"success": True, "data": list_prices()}
    raise ValueError(f"Unknown pricelist action: {action}")
