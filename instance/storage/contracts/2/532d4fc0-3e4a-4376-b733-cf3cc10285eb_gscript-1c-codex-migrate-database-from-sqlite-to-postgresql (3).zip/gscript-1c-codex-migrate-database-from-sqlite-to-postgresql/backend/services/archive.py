from __future__ import annotations

import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

from backend.db import DATABASE_URL, SessionLocal, commit_with_retry
from backend.models import ArchiveEntry
from backend.services.storage import STORAGE_ROOT

ARCHIVE_DIR = Path("instance/archives")


def build_manual_archive() -> Dict[str, Any]:
    ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"archive_{timestamp}.zip"
    archive_path = ARCHIVE_DIR / filename

    with zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED) as archive:
        if DATABASE_URL.startswith("sqlite"):
            db_path = Path("instance/app.db")
            if db_path.exists():
                archive.write(db_path, arcname="app.db")
        # TODO: for PostgreSQL add pg_dump-based export into archive (future multi-tenant support).
        if STORAGE_ROOT.exists():
            for file_path in STORAGE_ROOT.rglob("*"):
                if file_path.is_file():
                    relative_path = file_path.relative_to(STORAGE_ROOT)
                    archive.write(file_path, arcname=f"storage/contracts/{relative_path.as_posix()}")

    session = SessionLocal()
    try:
        entry = ArchiveEntry(filename=filename)
        session.add(entry)
        commit_with_retry(session)
    finally:
        session.close()

    return {"downloadUrl": f"/archive/{filename}"}


def handle(action: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    if action == "downloadProjectArchive":
        return {"success": True, "data": build_manual_archive()}
    raise ValueError(f"Unknown archive action: {action}")
