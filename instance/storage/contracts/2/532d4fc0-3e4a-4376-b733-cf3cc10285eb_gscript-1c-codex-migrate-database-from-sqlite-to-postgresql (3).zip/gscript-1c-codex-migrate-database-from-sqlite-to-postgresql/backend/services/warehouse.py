from __future__ import annotations

from datetime import date, datetime
from typing import Any, Dict, List

from sqlalchemy import select

from backend.db import SessionLocal, commit_with_retry
from backend.models import Contract, ContractItem, WarehouseExpense, WarehouseIncome, WarehouseItem
from backend.services.utils import format_date, normalize_text, parse_date, to_float

EXPENSES_CUTOFF = date(2025, 12, 6)


def _normalize_item_name(value: Any) -> str:
    return normalize_text(value)


def _normalize_in_stock(value: Any) -> bool:
    if value in (None, ""):
        return True
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    if text in {"true", "yes", "1"}:
        return True
    if text in {"false", "no", "0"}:
        return False
    return True


def _get_items_index(session) -> Dict[str, WarehouseItem]:
    items = session.execute(select(WarehouseItem)).scalars().all()
    return {item.name: item for item in items}


def list_items() -> List[Dict[str, Any]]:
    session = SessionLocal()
    try:
        items = session.execute(select(WarehouseItem)).scalars().all()
        return [
            {
                "id": item.id,
                "name": item.name,
                "unit": item.unit,
                "active": bool(item.active),
            }
            for item in items
        ]
    finally:
        session.close()


def create_item(payload: Dict[str, Any]) -> None:
    name = _normalize_item_name(payload.get("name"))
    if not name:
        raise ValueError("Наименование товара обязательно")
    session = SessionLocal()
    try:
        session.add(
            WarehouseItem(
                name=name,
                unit=normalize_text(payload.get("unit")),
                active=True,
            )
        )
        commit_with_retry(session)
    finally:
        session.close()


def update_item(payload: Dict[str, Any]) -> None:
    item_id = payload.get("id")
    if not item_id:
        raise ValueError("id is required for updateItem")
    session = SessionLocal()
    try:
        item = session.get(WarehouseItem, item_id)
        if not item:
            raise ValueError("Товар не найден")
        name = _normalize_item_name(payload.get("name"))
        if not name:
            raise ValueError("Наименование товара обязательно")
        item.name = name
        item.unit = normalize_text(payload.get("unit"))
        item.active = bool(payload.get("active", True))
        commit_with_retry(session)
    finally:
        session.close()


def delete_item(item_id: str) -> None:
    if not item_id:
        raise ValueError("id is required for deleteItem")
    session = SessionLocal()
    try:
        item = session.get(WarehouseItem, item_id)
        if not item:
            raise ValueError("Товар не найден")
        session.delete(item)
        commit_with_retry(session)
    finally:
        session.close()


def get_item(item_id: str) -> Dict[str, Any] | None:
    session = SessionLocal()
    try:
        item = session.get(WarehouseItem, item_id)
        if not item:
            return None
        return {
            "id": item.id,
            "name": item.name,
            "unit": item.unit,
            "active": bool(item.active),
        }
    finally:
        session.close()


def list_incomes() -> List[Dict[str, Any]]:
    session = SessionLocal()
    try:
        items_index = _get_items_index(session)
        incomes = session.execute(select(WarehouseIncome)).scalars().all()
        result = []
        for income in incomes:
            item_info = items_index.get(income.item)
            unit_val = item_info.unit if item_info else income.unit
            result.append(
                {
                    "id": income.id,
                    "item": income.item,
                    "invoiceNumber": income.invoice_number,
                    "date": format_date(income.date),
                    "qty": income.qty,
                    "unit": unit_val or "",
                    "inStock": bool(income.in_stock),
                }
            )
        return result
    finally:
        session.close()


def _ensure_existing_item(session, item_name: str) -> WarehouseItem:
    item = session.execute(select(WarehouseItem).where(WarehouseItem.name == item_name)).scalar_one_or_none()
    if not item:
        raise ValueError(
            f'Товар "{item_name}" отсутствует в перечне товаров. '
            "Сначала заполните информацию о товаре в реестре, затем возвращайтесь в эту вкладку."
        )
    return item


def create_income(payload: Dict[str, Any]) -> None:
    item_name = _normalize_item_name(payload.get("item"))
    if not item_name:
        raise ValueError("Наименование товара обязательно для прихода.")

    session = SessionLocal()
    try:
        item_info = _ensure_existing_item(session, item_name)
        income = WarehouseIncome(
            item=item_name,
            invoice_number=normalize_text(payload.get("invoiceNumber")),
            date=parse_date(payload.get("date")),
            qty=to_float(payload.get("qty")) if payload.get("qty") not in (None, "") else 0,
            unit=item_info.unit or "",
            in_stock=_normalize_in_stock(payload.get("inStock")),
        )
        session.add(income)
        commit_with_retry(session)
    finally:
        session.close()


def update_income(payload: Dict[str, Any]) -> None:
    income_id = payload.get("id")
    if not income_id:
        raise ValueError("id is required for updateIncome")

    session = SessionLocal()
    try:
        income = session.get(WarehouseIncome, income_id)
        if not income:
            raise ValueError("Приход с таким ID не найден")
        item_name = _normalize_item_name(payload.get("item"))
        if not item_name:
            raise ValueError("Наименование товара обязательно для прихода.")
        item_info = _ensure_existing_item(session, item_name)
        income.item = item_name
        income.invoice_number = normalize_text(payload.get("invoiceNumber"))
        income.date = parse_date(payload.get("date"))
        income.qty = to_float(payload.get("qty")) if payload.get("qty") not in (None, "") else 0
        income.unit = item_info.unit or ""
        income.in_stock = _normalize_in_stock(payload.get("inStock"))
        commit_with_retry(session)
    finally:
        session.close()


def delete_income(income_id: str) -> None:
    if not income_id:
        raise ValueError("Приход с таким ID не найден")
    session = SessionLocal()
    try:
        income = session.get(WarehouseIncome, income_id)
        if not income:
            raise ValueError("Приход с таким ID не найден")
        session.delete(income)
        commit_with_retry(session)
    finally:
        session.close()


def get_income(income_id: str) -> Dict[str, Any] | None:
    session = SessionLocal()
    try:
        income = session.get(WarehouseIncome, income_id)
        if not income:
            return None
        return {
            "id": income.id,
            "item": income.item,
            "invoiceNumber": income.invoice_number,
            "date": format_date(income.date),
            "qty": income.qty,
            "unit": income.unit,
            "inStock": bool(income.in_stock),
        }
    finally:
        session.close()


def _extract_contract_items(contract: Contract) -> List[Dict[str, Any]]:
    items = [
        {
            "item": item.item,
            "qty": item.qty,
            "planQty": item.plan_qty,
            "planDate": item.plan_date,
            "dateFact": item.date_fact,
            "delivered": item.delivered,
        }
        for item in contract.items
    ]
    if not items:
        items = [
            {
                "item": contract.item,
                "qty": contract.qty,
                "planQty": contract.plan_qty,
                "planDate": contract.plan_date,
                "dateFact": contract.date_fact,
                "delivered": contract.delivered,
            }
        ]
    return items


def _build_expenses(session) -> List[Dict[str, Any]]:
    contracts = session.execute(select(Contract).order_by(Contract.order_index)).scalars().all()
    result = []
    for contract in contracts:
        items = _extract_contract_items(contract)
        for item in items:
            item_name = _normalize_item_name(item.get("item") or contract.item)
            date_fact = item.get("dateFact") or contract.date_fact
            if not item_name or not date_fact:
                continue
            if isinstance(date_fact, datetime):
                date_fact = date_fact.date()
            if date_fact < EXPENSES_CUTOFF:
                continue

            qty = item.get("delivered") or item.get("qty") or 0
            result.append(
                {
                    "id": contract.id,
                    "org": contract.org or "",
                    "date": format_date(date_fact),
                    "item": item_name,
                    "qty": qty,
                    "contractNumber": contract.number or "",
                }
            )
    return result


def list_expenses() -> List[Dict[str, Any]]:
    session = SessionLocal()
    try:
        return _build_expenses(session)
    finally:
        session.close()


def delete_expense(payload: Dict[str, Any]) -> None:
    expense_id = payload.get("id")
    if not expense_id:
        raise ValueError("id is required for deleteExpense")

    session = SessionLocal()
    try:
        contract = session.get(Contract, expense_id)
        if not contract:
            raise ValueError("Contract not found for expense %s" % expense_id)
        contract.date_fact = None
        contract.delivered = 0
        commit_with_retry(session)
    finally:
        session.close()


def balances_by_date(date_str: str | None) -> List[Dict[str, Any]]:
    session = SessionLocal()
    try:
        end_date = parse_date(date_str) or date.today()
        end_time = datetime(end_date.year, end_date.month, end_date.day, 23, 59, 59, 999000)

        incomes = session.execute(select(WarehouseIncome)).scalars().all()
        expenses = _build_expenses(session)
        balances: Dict[str, float] = {}

        for income in incomes:
            if not income.date:
                continue
            income_date = datetime.combine(income.date, datetime.min.time())
            if income_date > end_time:
                continue
            if not _normalize_in_stock(income.in_stock):
                continue
            qty = income.qty or 0
            balances[income.item] = balances.get(income.item, 0) + qty

        for expense in expenses:
            exp_date = parse_date(expense.get("date"))
            if not exp_date:
                continue
            if datetime.combine(exp_date, datetime.min.time()) > end_time:
                continue
            item = _normalize_item_name(expense.get("item"))
            balances[item] = balances.get(item, 0) - (expense.get("qty") or 0)

        items = session.execute(select(WarehouseItem)).scalars().all()
        result = []
        for item in items:
            qty = balances.get(item.name, 0)
            result.append(
                {
                    "date": format_date(end_date),
                    "item": item.name,
                    "qty": qty,
                }
            )

        return sorted(result, key=lambda row: row["item"])
    finally:
        session.close()


def list_moves() -> List[Dict[str, Any]]:
    session = SessionLocal()
    try:
        incomes = session.execute(select(WarehouseIncome)).scalars().all()
        expenses = _build_expenses(session)
        moves = []
        for income in incomes:
            moves.append(
                {
                    "date": format_date(income.date),
                    "contractNumber": income.invoice_number or "",
                    "item": income.item,
                    "operationType": "Приход",
                    "qty": income.qty,
                }
            )
        for expense in expenses:
            moves.append(
                {
                    "date": expense.get("date", ""),
                    "contractNumber": expense.get("contractNumber", ""),
                    "item": expense.get("item", ""),
                    "operationType": "Расход",
                    "qty": expense.get("qty", 0),
                }
            )

        def sort_key(entry):
            d = parse_date(entry.get("date"))
            return d or date.min

        return sorted(moves, key=sort_key)
    finally:
        session.close()


def handle(action: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    if action == "balancesByDate":
        return {"success": True, "data": balances_by_date(payload.get("date"))}
    if action == "listIncomes":
        return {"success": True, "data": list_incomes()}
    if action == "listExpenses":
        return {"success": True, "data": list_expenses()}
    if action == "deleteExpense":
        delete_expense(payload)
        return {"success": True, "data": list_expenses()}
    if action == "createIncome":
        create_income(payload)
        return {"success": True, "data": list_incomes()}
    if action == "updateIncome":
        update_income(payload)
        return {"success": True, "data": list_incomes()}
    if action == "deleteIncome":
        delete_income(payload.get("id"))
        return {"success": True, "data": list_incomes()}
    if action == "getIncomeById":
        return {"success": True, "data": get_income(payload.get("id"))}
    if action == "listMoves":
        return {"success": True, "data": list_moves()}
    if action == "listItems":
        return {"success": True, "data": list_items()}
    if action == "createItem":
        create_item(payload)
        return {"success": True, "data": list_items()}
    if action == "updateItem":
        update_item(payload)
        return {"success": True, "data": list_items()}
    if action == "deleteItem":
        delete_item(payload.get("id"))
        return {"success": True, "data": list_items()}
    if action == "getItemById":
        return {"success": True, "data": get_item(payload.get("id"))}
    raise ValueError(f"Unknown warehouse action: {action}")
