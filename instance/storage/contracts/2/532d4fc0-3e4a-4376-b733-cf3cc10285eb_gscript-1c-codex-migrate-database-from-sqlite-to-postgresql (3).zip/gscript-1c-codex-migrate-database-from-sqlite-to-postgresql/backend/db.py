import os
import time
from urllib.parse import quote_plus

from sqlalchemy.exc import OperationalError

from sqlalchemy import create_engine, event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import declarative_base, scoped_session, sessionmaker


def _build_database_url() -> str:
    explicit_url = os.getenv("DATABASE_URL")
    if explicit_url:
        return explicit_url
    password = quote_plus(os.getenv("POSTGRES_PASSWORD", ""))
    base_url = f"postgresql+psycopg2://postgres:{password}@127.0.0.1:5432/gscript"
    sslmode = os.getenv("POSTGRES_SSLMODE")
    if sslmode:
        return f"{base_url}?sslmode={sslmode}"
    return base_url


DATABASE_URL = _build_database_url()

engine_kwargs = {"future": True, "pool_pre_ping": True}
if DATABASE_URL.startswith("sqlite"):
    engine_kwargs["connect_args"] = {"check_same_thread": False}

engine = create_engine(DATABASE_URL, **engine_kwargs)

SessionLocal = scoped_session(
    sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)
)

Base = declarative_base()


def init_db() -> None:
    os.makedirs("instance", exist_ok=True)
    Base.metadata.create_all(bind=engine)


def commit_with_retry(session, retries: int = 5, base_delay: float = 0.05) -> None:
    attempt = 0
    while True:
        try:
            session.commit()
            return
        except OperationalError as exc:
            message = str(exc).lower()
            if "database is locked" not in message or attempt >= retries:
                raise
            session.rollback()
            time.sleep(base_delay * (2**attempt))
            attempt += 1


@event.listens_for(Engine, "connect")
def configure_sqlite(dbapi_connection, connection_record) -> None:
    if not DATABASE_URL.startswith("sqlite"):
        return
    cursor = dbapi_connection.cursor()
    cursor.execute("PRAGMA foreign_keys=ON")
    cursor.execute("PRAGMA journal_mode=WAL")
    cursor.execute("PRAGMA busy_timeout=5000")
    cursor.close()
