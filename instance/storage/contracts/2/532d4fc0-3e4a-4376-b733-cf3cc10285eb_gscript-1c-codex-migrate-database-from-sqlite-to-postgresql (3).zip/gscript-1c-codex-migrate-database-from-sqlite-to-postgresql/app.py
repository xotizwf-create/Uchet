from __future__ import annotations

from pathlib import Path

from flask import Flask, jsonify, render_template, request, send_from_directory
from sqlalchemy import select

from backend.db import init_db
from backend.services import archive, commercials, contracts, dashboard, pricelist, warehouse
from backend.services.storage import get_user_storage_dir, normalize_user_id


def create_app() -> Flask:
    app = Flask(__name__)

    init_db()

    @app.route("/")
    def index():
        return render_template("index.html")

    @app.post("/api/appBackend")
    def app_backend():
        data = request.get_json(silent=True) or {}
        module = data.get("module")
        action = data.get("action")
        payload = data.get("payload") or {}

        handlers = {
            "contracts": contracts,
            "warehouse": warehouse,
            "pricelist": pricelist,
            "dashboard": dashboard,
            "commercials": commercials,
            "archive": archive,
        }

        handler = handlers.get(module)
        if not handler:
            return jsonify({"success": False, "error": f"Unknown module: {module}"})

        try:
            return jsonify(handler.handle(action, payload))
        except Exception as exc:  # noqa: BLE001
            return jsonify({"success": False, "error": str(exc)})

    @app.route("/drive/<file_id>")
    def download_drive_file(file_id: str):
        from backend.db import SessionLocal
        from backend.models import DriveFile

        user_id = normalize_user_id(request.args.get("userId"))
        session = SessionLocal()
        try:
            file = session.execute(select(DriveFile).where(DriveFile.id == file_id)).scalar_one_or_none()
            if not file or file.user_id != user_id:
                return ("Not found", 404)
            drive_dir = get_user_storage_dir(file.user_id)
            return send_from_directory(drive_dir, file.storage_name, as_attachment=True, download_name=file.name)
        finally:
            session.close()

    @app.route("/archive/<filename>")
    def download_archive(filename: str):
        archive_dir = Path("instance/archives")
        return send_from_directory(archive_dir, filename, as_attachment=True)

    return app


if __name__ == "__main__":
    create_app().run(host="0.0.0.0", port=5000, debug=True)
